#ifndef NODE_H_INCLUDED
#define NODE_H_INCLUDED

#include <string>
using namespace std;

class Node
{

private:
    string name;
    vector<string> noteMessages;
    bool isSource;
    bool isTarget;
public:
    Node (string name, vector<string> noteMessages, bool isSource=false, bool isTarget=false)
    {
        Node::name = name;
        Node::noteMessages = noteMessages;
        Node::isSource = isSource;
        Node::isTarget = isTarget;
    }

    string get_name ()
    {
        return name;
    }

    vector<string> get_noteMessages ()
    {
        return noteMessages;
    }
    void print(){
        cout<< name <<endl;
        for (unsigned int i=0;i<noteMessages.size();i++){
            cout <<i<<noteMessages[i]<<endl;
        }
    }
};

#endif // NODE_H_INCLUDED
