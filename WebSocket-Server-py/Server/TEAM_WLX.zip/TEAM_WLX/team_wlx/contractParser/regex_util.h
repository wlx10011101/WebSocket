#ifndef REGEX_UTIL_H_INCLUDED
#define REGEX_UTIL_H_INCLUDED

#include <regex>

class RegexUtil {

public:

    static bool reg_search (string target, string regExpression)
    {
        regex re(regExpression);
        smatch mr2;
        return regex_search(target, mr2, re);
    }
};

#endif // REGEX_UTIL_H_INCLUDED
