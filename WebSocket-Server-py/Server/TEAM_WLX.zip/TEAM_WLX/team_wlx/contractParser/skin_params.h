#ifndef SKIN_PARAMS_H_INCLUDED
#define SKIN_PARAMS_H_INCLUDED

#include <vector>
using namespace std;

class SkinParams
{
private:
    vector<string> params;
public:
    SkinParams (vector<string> params) {
        SkinParams::params = params;
    }

    vector<string> get_params() {
        return params;
    }
};

#endif // SKIN_PARAMS_H_INCLUDED
