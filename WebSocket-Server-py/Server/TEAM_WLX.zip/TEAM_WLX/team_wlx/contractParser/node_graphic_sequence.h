#ifndef NODE_GRAPHIC_SEQUENCE_H_INCLUDED
#define NODE_GRAPHIC_SEQUENCE_H_INCLUDED

#include <vector>
using namespace std;

class NodeGraphicSequence {
public:
    static NodeGraphicSequence *getInstance();
    void add_node(string nodeName);
	vector<string> get_node_sequence();
	bool check_node_position(string leftNode, string rightNode);
	void clear();

private:
    vector<string> nodeSequence;
    static NodeGraphicSequence* instance;
    NodeGraphicSequence();
    NodeGraphicSequence(const NodeGraphicSequence&);
	NodeGraphicSequence& operator=(const NodeGraphicSequence&);

	bool find_node(string nodeName);
};

NodeGraphicSequence* NodeGraphicSequence::instance = new NodeGraphicSequence();

NodeGraphicSequence::NodeGraphicSequence(){}

NodeGraphicSequence::NodeGraphicSequence(const NodeGraphicSequence&){}

NodeGraphicSequence& NodeGraphicSequence::operator=(const NodeGraphicSequence&){}

NodeGraphicSequence* NodeGraphicSequence::getInstance(){
	return instance;
}

void NodeGraphicSequence::add_node(string nodeName)
{
    if (find_node(nodeName))
        return;
    nodeSequence.push_back(nodeName);
}

vector<string> NodeGraphicSequence::get_node_sequence()
{
    return nodeSequence;
}

bool NodeGraphicSequence::find_node(string nodeName)
{
    auto index=std::find(nodeSequence.begin(),nodeSequence.end(),nodeName);
    return index!=nodeSequence.end();
}

bool NodeGraphicSequence::check_node_position(string leftNode, string rightNode) {
    auto leftTextGraphIndex = std::find(nodeSequence.begin(),nodeSequence.end(), leftNode);
    auto rightTextGraphIndex = std::find(nodeSequence.begin(),nodeSequence.end(), rightNode);
    return rightTextGraphIndex >= leftTextGraphIndex;
}

void NodeGraphicSequence::clear(){
    NodeGraphicSequence::nodeSequence.clear();
}


#endif // NODE_GRAPHIC_SEQUENCE_H_INCLUDED
