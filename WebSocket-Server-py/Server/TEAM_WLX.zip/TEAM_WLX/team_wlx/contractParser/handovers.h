#ifndef HANDOVERS_H_INCLUDED
#define HANDOVERS_H_INCLUDED

#include <iostream>
#include <vector>
#include "handover_block.h"

using namespace std;

class Handovers {
private:
    vector<HandoverBlock> handovers;

public:
    Handovers(){}
    vector<HandoverBlock> fake_print (vector<string> fakedNodes);

    void add_handover_block_object(HandoverBlock block) {
        vector<string> nodeNames = block.get_ordered_node_name();
        NodeGraphicSequence *nodeSequence = NodeGraphicSequence::getInstance();
        for (unsigned int i = 0; i < nodeNames.size(); i++) {
            nodeSequence->add_node(nodeNames[i]);
        }
        handovers.push_back(block);
    }

    vector<string> get_node_sequence() {
        NodeGraphicSequence *nodeSequence = NodeGraphicSequence::getInstance();
        return nodeSequence->get_node_sequence();
    }


    vector<HandoverBlock> get_handover_blocks() {
        return handovers;
    }

};

vector<HandoverBlock> Handovers::fake_print (vector<string> fakedNodes){
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    nodeGraphicSequence->clear();
    cout << "<<<<<<<<<<<<<<<<<<fake print<<<<<<<<<<<<<<<<<<<<<<<"<<endl;
    for (unsigned int i = 0; i < handovers.size(); i++) {
        HandoverBlock block = handovers[i];
        vector<string> blockFakePrint = block.fake_print(fakedNodes);
        for(unsigned int i=0; i < blockFakePrint.size(); i++){
            cout<< blockFakePrint[i]<<endl;
        }
//        if (block.has_node("BPF")) {
//            cout << block.orderedNodeName[0] << " " << block.symbol << " ";
//            cout << block.orderedNodeName[1] << ": " << block.message << endl;
//            nodeGraphicSequence->add_node(block.orderedNodeName[0]);
//            nodeGraphicSequence->add_node(block.orderedNodeName[1]);
//        }
    }
    return  handovers;
}

#endif // HANDOVERS_H_INCLUDED
