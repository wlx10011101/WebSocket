#ifndef UMLPARSER_H_INCLUDED
#define UMLPARSER_H_INCLUDED

#include "skin_params.h"
#include "handovers.h"
#include <fstream>

using namespace std;

class UmlParser
{
public:
    SkinParams *skinParams;
    Handovers *handovers;
public:
    UmlParser ()
    {
        handovers = new Handovers();
    }

    bool parse(string filePath)
    {
        char buffer[256];
        ifstream wsdFile(filePath);
        bool recordStart = false;
        bool handoverStart = false;

        vector<string> config;
        vector<string> handoverBlock;

        if (! wsdFile.is_open())
        {
            cout << "file not found" << endl;
            return 0;
        }
        while (! wsdFile.eof())
        {
            wsdFile.getline(buffer, 100);
            if (startsWithSymbolAnd(string(buffer)))
            {
                recordStart = true;
                continue;
            }
            if (endsWithSymbolAnd(string(buffer)))
            {
                handovers->add_handover_block_object(HandoverBlock(handoverBlock));
                recordStart = false;
            }
            if (recordStart)
            {
                if (isSkinConfigure(string(buffer)))
                {
                    config.push_back(string(buffer));
                    continue;
                }
                if (is_handover_message(string(buffer)))
                {
                    handoverStart = true;
                    if (! handoverBlock.empty())
                    {
                        handovers->add_handover_block_object(HandoverBlock(handoverBlock));
                        handoverBlock.clear();
                    }
                    handoverBlock.push_back(string(buffer));
                }
                else
                {
                    if (handoverStart) {
                        handoverBlock.push_back(string(buffer));
                    }

                }
            }
        }
        skinParams = new SkinParams(config);
        return true;
    }

    SkinParams get_skin_params ()
    {
        return *skinParams;
    }

    Handovers get_handovers ()
    {
        return *handovers;
    }

private:
    bool reg_search (string target, string regExpression)
    {
        regex re(regExpression);
        smatch mr2;
        return regex_search(target, mr2, re);
    }

    bool reg_match (string target, string regExpression)
    {
        regex re(regExpression);
        return regex_match(target, re);
    }

    bool startsWithSymbolAnd(string target)
    {
        return reg_match(target, "^@startuml$");
    }

    bool endsWithSymbolAnd(string target)
    {
        return reg_match(target, "^@enduml$");
    }

    bool isSkinConfigure(string target)
    {
        return reg_match(target, "skinparam[\\s\\S]+");
    }

    bool is_handover_message(string msg)
    {
        return reg_search(msg, "->") || reg_search(msg, "<-");
    }
};

#endif // UMLPARSER_H_INCLUDED
