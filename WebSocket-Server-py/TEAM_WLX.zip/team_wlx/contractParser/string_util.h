#ifndef STRING_UTIL_H_INCLUDED
#define STRING_UTIL_H_INCLUDED
#include<string>

class StringUtil
{
public:
    static vector<string> split(const string& src, string separate_character)
    {
        vector<string> strs;
        int separate_characterLen = separate_character.size();
        int lastPosition = 0, index = -1;
        while (-1 != (index = src.find(separate_character, lastPosition)))
        {
            strs.push_back(src.substr(lastPosition, index - lastPosition));
            lastPosition = index + separate_characterLen;
        }
        string lastString = src.substr(lastPosition);
        if (!lastString.empty())
        {
            strs.push_back(lastString);
        }
        return strs;
    }

    static string& trim(string &s)
    {
        if (s.empty())
        {
            return s;
        }
        s.erase(0,s.find_first_not_of(" "));
        s.erase(s.find_last_not_of(" ") + 1);
        return s;
    }

    static vector<string>& trim(vector<string> &s)
    {
        for (unsigned int i = 0; i < s.size(); i++) {
            if (s[i].empty())
            {
                return s;
            }
            s[i].erase(0,s[i].find_first_not_of(" "));
            s[i].erase(s[i].find_last_not_of(" ") + 1);
        }
        return s;
    }
    static bool is_in_list(string s, vector<string> stringList){
        for (unsigned int i = 0; i < stringList.size(); i++ ){
            if (s == stringList[i]){
                return true;
            }
        }
        return false;
    }
};


#endif // STRING_UTIL_H_INCLUDED
