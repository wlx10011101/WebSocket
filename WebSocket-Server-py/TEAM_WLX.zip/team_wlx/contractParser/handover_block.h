#ifndef HANDOVER_BLOCK_H_INCLUDED
#define HANDOVER_BLOCK_H_INCLUDED

#include <iostream>
#include <vector>
#include "node.h"
#include "string_util.h"
#include "regex_util.h"
#include "node_graphic_sequence.h"

using namespace std;

class HandoverBlock
{
public:
    vector<Node> orderNode;
    Node *source;
    Node *target;
    string symbol;
    string message;
    vector<string> orderedNodeName;

public:
    HandoverBlock(vector<string> handoverBlock);
    vector<string> get_ordered_node_name ();
    bool has_node(string nodeName);
    vector<string> fake_print(vector<string> fakeNodeList)

private:
    void parse_head(string blockHead);
    map<string, vector<string>> parse_note (vector<string> handoverBlock, vector<string> nodeSequence);
    string first_node_name(string head);
    string second_node_name(string head);
    string symbol_string(string head);
    unsigned int get_symbol_start_index(string head);
    unsigned int get_symbol_end_index (string head);

    bool is_graphic_left_note (string note_head);
    bool is_graphic_right_note (string note_head);

    Node node_name_find_node_obj(string nodeName);
};

HandoverBlock::HandoverBlock(vector<string> handoverBlock)
{
    parse_head(handoverBlock[0]);
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    map<string, vector<string>> noteMap = parse_note(handoverBlock, nodeGraphicSequence->get_node_sequence());
    vector <int> order = {0, 1};
    if (RegexUtil::reg_search(symbol, "<"))order = {1, 0};
    source = new Node(orderedNodeName[0], noteMap.find(orderedNodeName[order[0]])->second);
    target = new Node(orderedNodeName[1], noteMap.find(orderedNodeName[order[1]])->second);
}

vector<string> HandoverBlock::get_ordered_node_name ()
{
    return orderedNodeName;
}

bool HandoverBlock::has_node(string nodeName)
{
    for (unsigned int i = 0; i < orderedNodeName.size(); i++)
    {
        if (nodeName == orderedNodeName[i])
            return true;
    }
    return false;
}

void HandoverBlock::parse_head(string blockHead)
{
    vector<string> tmp = StringUtil::split(blockHead, ":");
    StringUtil::trim(tmp);
    message = tmp[1];
    symbol = symbol_string(tmp[0]);
    orderedNodeName.push_back(first_node_name(tmp[0]));
    orderedNodeName.push_back(second_node_name(tmp[0]));
}

map<string, vector<string>> HandoverBlock::parse_note (vector<string> handoverBlock, vector<string> nodeSequence)
{
    map<string, vector<string>> noteMap;
    vector<string> noteLeftTextList;
    vector<string> noteRightTextList;
    for (unsigned int i = 1; i < handoverBlock.size(); i++)
    {
        vector<string> tmp = StringUtil::split(handoverBlock[i], ":");
        StringUtil::trim(tmp);
        if (is_graphic_right_note(tmp[0]))
        {
            noteRightTextList.push_back(tmp[1]);
        }
        if (is_graphic_left_note(tmp[0]))
        {
            noteLeftTextList.push_back(tmp[1]);
        }
    }

    noteMap.insert(pair<string, vector<string>>(orderedNodeName[0], noteLeftTextList));
    noteMap.insert(pair<string, vector<string>>(orderedNodeName[1], noteRightTextList));
    return noteMap;
}

string HandoverBlock::first_node_name(string head)
{
    string tmp = "";
    for (unsigned int i = 0; i < get_symbol_start_index(head); i++)
    {
        tmp += head[i];
    }
    return StringUtil::trim(tmp);
}

string HandoverBlock::second_node_name(string head)
{
    string tmp = "";
    for (unsigned int i = get_symbol_end_index(head) + 1; i < head.size(); i++)
    {
        tmp += head[i];
    }
    return StringUtil::trim(tmp);
}

string HandoverBlock::symbol_string(string head)
{
    string tmp = "";
    for (unsigned int i = get_symbol_start_index(head); i <= get_symbol_end_index(head); i++)
    {
        tmp += head[i];
    }
    return StringUtil::trim(tmp);
}

unsigned int HandoverBlock::get_symbol_start_index(string head)
{
    for (unsigned int i = 0; i < head.size(); i++)
    {
        if (head[i] == '-' || head[i] == '>' || head[i] == '<')
        {
            return i;
        }
    }
    return 0;
}

unsigned int HandoverBlock::get_symbol_end_index (string head)
{
    for (unsigned int i = head.size() - 1; i >= 0; i--)
    {
        if (head[i] == '-' || head[i] == '>' || head[i] == '<')
        {
            return i;
        }
    }
    return head.size();
}

bool HandoverBlock::is_graphic_left_note (string note_head)
{
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    return (nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(note_head, "note left")) ||
           (! nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(note_head, "note right"));
}

bool HandoverBlock::is_graphic_right_note (string note_head)
{
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    return (nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(note_head, "note right")) ||
           (! nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(note_head, "note left"));
}

vector<string> HandoverBlock::fake_print(vector<string> fakeNodeList){
    fakeTimes = 0;
    vector<string>fakeNodeName;
    vector<string>result;
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    for (unsigned int i=0; i<orderedNodeName.size(); i++){
        if (StringUtil::is_in_list(orderedNodeName[i],fakeNodeList)){
            ++fakeTimes;
            fakeNodeName.push_back("FAKE");
           }
        else{
            fakeNodeName.push_back(orderedNodeName[i])
        }
    }
    if (fakeTimes<2){

    }

}

Node HandoverBlock::node_name_find_node_obj(string nodeName){
    vector <int> order = {0, 1};
    if (RegexUtil::reg_search(symbol, "<"))order = {1, 0};

}
#endif // HANDOVER_BLOCK_H_INCLUDED
