#include <iostream>
#include "umlparser.h"
using namespace std;

int main ()
{

    UmlParser umlParse;
    umlParse.parse("../attach.wsd");
    Handovers handovers = umlParse.get_handovers();
    vector<string> fakelist = {"BPF"};
    handovers.fake_print(fakelist);
//    vector<HandoverBlock> blocks = handovers.get_handover_blocks();
//    vector<string> tmpSequence;
//    for (unsigned int i = 0; i < blocks.size(); i++) {
//        if (blocks[i].has_node("BPF")) {
//            cout << blocks[i].orderedNodeName[0] << " " << blocks[i].symbol << " ";
//            cout << blocks[i].orderedNodeName[1] << ": " << blocks[i].message << endl;
//            tmpSequence.push_back(blocks[i].orderedNodeName[0]);
//            tmpSequence.push_back(blocks[i].orderedNodeName[1]);
//
//            auto sourceTextGraphIndex = std::find(tmpSequence.begin(),tmpSequence.end(), blocks[i].source->get_name());
//            auto targetGraphIndex = std::find(tmpSequence.begin(),tmpSequence.end(), blocks[i].target->get_name());
//
//            bool sourceLeft = targetGraphIndex > sourceTextGraphIndex;
//
//            if (blocks[i].source->get_notes().size() > 0) {
//                string message = blocks[i].source->get_notes()[0];
//                if (sourceLeft) {
//                    message = "note left: " + message;
//                }
//                else {
//                    message = "note right: " + message;
//                }
//                cout << message << endl;
//            }
//            if (blocks[i].target->get_notes().size() > 0) {
//                string message = blocks[i].target->get_notes()[0];
//                if (sourceLeft) {
//                    message = "note right: " + message;
//                }
//                else {
//                    message = "note left: " + message;
//                }
//                cout << message << endl;
//            }
//
//        }
//    }
}
