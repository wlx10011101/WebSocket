#include <iostream>
#include <fstream>
#include <regex>
#include <string>

using namespace std;


bool regmatch(string target, string regExpression);
bool is_handover(string message);
bool is_footer_head (string message);

bool regmatch (string target, string regExpression)
{
    regex re(regExpression);
    smatch mr2;
    bool result = regex_search(target, mr2, re);
    return result;
}

bool is_handover (string message)
{
    return regmatch(message, "[\\s\\S]+->[\\s\\S]+") || regmatch(message, "[\\s\\S]+<-[\\s\\S]+");
}

bool is_footer_head (string message)
{
    return regmatch(message, "@enduml");
}


bool has_specific_node (string message, int argc, char* argv[])
{
    bool flag = false;
    for(int i = 0; i < argc; i++)
    {
        flag = flag || regmatch(message, string(argv[i]) + string("[\\s\\S]+"));
    }
    return flag;
}

int main_bk (int argc, char* argv[])
{
    char buffer[256];
    ifstream wsdFile("../../../attach.wsd");
    bool mask = false;

    if (! wsdFile.is_open())
    {
        cout << "file not found" << endl;
        return 0;
    }
    while (! wsdFile.eof())
    {
        wsdFile.getline(buffer, 100);
        if (! is_handover(string(buffer)))
        {
            if (is_footer_head(string(buffer)))
            {
                mask = false;
            }
        }
        else
        {
            mask = true;
            if (has_specific_node(string(buffer), argc, argv))
            if (true)
            {
                mask = false;
            }
        }

        if (! mask)
        {
            cout << string(buffer) << endl;
        }
    }
    return 0;
}

