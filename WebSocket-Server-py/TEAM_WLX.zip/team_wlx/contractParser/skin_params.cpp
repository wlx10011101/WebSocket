#include <iostream>
#include <vector>
using namespace std;

class SkinParams
{
private:
    vector<string> params;
public:
    SkinParams (vector<string> params) {
        SkinParams::params = params;
    }

    vector<string> get_params() {
        return params;
    }
};
