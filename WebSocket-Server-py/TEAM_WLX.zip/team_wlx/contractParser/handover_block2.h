
#ifndef HANDOVER_BLOCK_H_INCLUDED
#define HANDOVER_BLOCK_H_INCLUDED

#include <iostream>
#include <vector>
#include "node.h"
#include "string_util.h"
#include "regex_util.h"
#include "node_graphic_sequence.h"

using namespace std;

class HandoverBlock
{
private:
    vector<Node*> orderedNode;
    string symbol;
    string message;

public:
    HandoverBlock(vector<string> handoverBlock);
    vector<string> get_ordered_node_name ();
    bool has_node(string nodeName);
    vector<string> fake_print(vector<string> fakeNodeList);

private:
    vector<string> parse_head(string blockHead);
    map<string, vector<string>> parse_note (vector<string> handoverBlock, vector<string> orderedNodeName,vector<string> nodeSequence);
    string first_node_name(string head);
    string second_node_name(string head);
    string symbol_string(string head);
    unsigned int get_symbol_start_index(string head);
    unsigned int get_symbol_end_index (string head);

    bool is_graphic_left_note (vector<string> orderedNodeName, string note_head);
    bool is_graphic_right_note (vector<string> orderedNodeName, string note_head);
};

HandoverBlock::HandoverBlock(vector<string> handoverBlock)
{
    vector<string>orderedNodeName = parse_head(handoverBlock[0]);
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    map<string, vector<string>> noteMap = parse_note(handoverBlock, orderedNodeName, nodeGraphicSequence->get_node_sequence());
    vector <int> order = {0, 1};
    if (RegexUtil::reg_search(symbol, "<"))
        order = {1, 0};
    orderedNode.push_back(new Node(orderedNodeName[0], noteMap.find(orderedNodeName[order[0]])->second, true, false));
    orderedNode.push_back(new Node(orderedNodeName[1], noteMap.find(orderedNodeName[order[1]])->second, false, true));
}

vector<string> HandoverBlock::get_ordered_node_name ()
{
    vector<string>result;
    for (unsigned i=0; i<orderedNode.size(); i++)
    {
        result.push_back(orderedNode[i]->get_name());
    }
    return result;
}

bool HandoverBlock::has_node(string nodeName)
{
    vector<string> orderedNodeName = get_ordered_node_name();
    for (unsigned int i = 0; i < orderedNodeName.size(); i++)
    {
        if (nodeName == orderedNodeName[i])
            return true;
    }
    return false;
}

vector<string> HandoverBlock::parse_head(string blockHead)
{
    vector<string> orderedNodeName;
    vector<string> tmp = StringUtil::split(blockHead, ":");
    StringUtil::trim(tmp);
    message = tmp[1];
    symbol = symbol_string(tmp[0]);
    orderedNodeName.push_back(first_node_name(tmp[0]));
    orderedNodeName.push_back(second_node_name(tmp[0]));
    return orderedNodeName;
}

map<string, vector<string>> HandoverBlock::parse_note (vector<string> handoverBlock, vector<string> orderedNodeName, vector<string> nodeSequence)
{
    map<string, vector<string>> noteMap;
    vector<string> noteLeftTextList;
    vector<string> noteRightTextList;
    for (unsigned int i = 1; i < handoverBlock.size(); i++)
    {
        vector<string> tmp = StringUtil::split(handoverBlock[i], ":");
        StringUtil::trim(tmp);
        if (is_graphic_right_note(orderedNodeName, tmp[0]))
        {
            noteRightTextList.push_back(tmp[1]);
        }
        if (is_graphic_left_note(orderedNodeName, tmp[0]))
        {
            noteLeftTextList.push_back(tmp[1]);
        }
    }

    noteMap.insert(pair<string, vector<string>>(orderedNodeName[0], noteLeftTextList));
    noteMap.insert(pair<string, vector<string>>(orderedNodeName[1], noteRightTextList));
    return noteMap;
}

string HandoverBlock::first_node_name(string head)
{
    string tmp = "";
    for (unsigned int i = 0; i < get_symbol_start_index(head); i++)
    {
        tmp += head[i];
    }
    return StringUtil::trim(tmp);
}

string HandoverBlock::second_node_name(string head)
{
    string tmp = "";
    for (unsigned int i = get_symbol_end_index(head) + 1; i < head.size(); i++)
    {
        tmp += head[i];
    }
    return StringUtil::trim(tmp);
}

string HandoverBlock::symbol_string(string head)
{
    string tmp = "";
    for (unsigned int i = get_symbol_start_index(head); i <= get_symbol_end_index(head); i++)
    {
        tmp += head[i];
    }
    return StringUtil::trim(tmp);
}

unsigned int HandoverBlock::get_symbol_start_index(string head)
{
    for (unsigned int i = 0; i < head.size(); i++)
    {
        if (head[i] == '-' || head[i] == '>' || head[i] == '<')
        {
            return i;
        }
    }
    return 0;
}

unsigned int HandoverBlock::get_symbol_end_index (string head)
{
    for (unsigned int i = head.size() - 1; i >= 0; i--)
    {
        if (head[i] == '-' || head[i] == '>' || head[i] == '<')
        {
            return i;
        }
    }
    return head.size();
}

bool HandoverBlock::is_graphic_left_note (vector<string> orderedNodeName, string note_head)
{
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    return (nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(note_head, "note left")) ||
           (! nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(note_head, "note right"));
}

bool HandoverBlock::is_graphic_right_note (vector<string> orderedNodeName, string note_head)
{
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    return (nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(note_head, "note right")) ||
           (! nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(note_head, "note left"));
}

vector<string> HandoverBlock::fake_print(vector<string> fakeNodeList)
{
    int fakeTimes = 0;
    vector<string>orderedNodeName = get_ordered_node_name();
    int fakeFlag[orderedNodeName.size()] = {0};
    vector<string>result;
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    for (unsigned int i=0; i<orderedNodeName.size(); i++)
    {
        if (StringUtil::is_in_list(orderedNodeName[i],fakeNodeList))
        {
            ++fakeTimes;
            fakeFlag[i] = 1;
            orderedNodeName[i] = "FAKE";
            nodeGraphicSequence->add_node("FAKE");
        }
        nodeGraphicSequence->add_node(orderedNodeName[i]);
    }
    if (fakeTimes<2)
    {
        string headTemp="";
        vector<string> noteKeyWord;
        if (nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]))
        {
            noteKeyWord = {"note left :", "note right :"};
        }else{
            noteKeyWord = {"note right :", "note left :"};
        }
        for (unsigned int i=0; i< orderedNode.size(); i++)
        {
            if (fakeFlag[i])
            {
                headTemp+= "FAKE1" + orderedNode[i]->get_name();

            }
            else
            {
                headTemp+= orderedNode[i]->get_name();

            }
            if (i==0){
                headTemp += symbol;
            }
            vector<string> notes= orderedNode[i]->get_noteMessages();
            for (unsigned int j=0; j < notes.size(); j++){
                result.push_back(noteKeyWord[i] + notes[j]);
            }
        }
        headTemp += ": " + message;
        result.insert(result.begin(),headTemp);
    }
    for (unsigned int i=0; i < result.size(); i++){
        cout<<result[i]<<endl;
    }
    return result;
}
#endif // HANDOVER_BLOCK_H_INCLUDED
