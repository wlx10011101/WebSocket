# coding:utf-8
import datetime
import os
import re
import shutil
import sys

from domain.model.DataTransferCfg import DataTransferCfg as config
from infrastructure.log import Logger


class DataTransferer(object):

    def __init__(self, inputFileName):
        self._inputFileName = inputFileName

    def _read_file(self, filePath):
        fileContents = []
        with open(filePath, 'r') as fp:
            for line in fp.readlines():
                data = line.strip()
                if len(data) != 0:
                    fileContents.append(data + '\n')
        return fileContents

    def _check_input_service_name(self, serviceName):
        for i in range(len(serviceName)):
            if serviceName[i] not in config.ALL_SERVICE_NAME:
                Logger.warn("Input the service name:{0} is not exit".format(serviceName[i]))
                return False
        return True

    def _split_file(self, fileContents):
        head, content, tail = [], [], []
        for i in range(len(fileContents)):
            if (config.CONTRACT_FLAG_LEFT in fileContents[i]) or (config.CONTRACT_FLAG_RIGHT in fileContents[i]):
                head = fileContents[:i]
                content = fileContents[i:len(fileContents) - 1]
                tail.append(fileContents[len(fileContents) - 1])
                break
        return head, content, tail

    def _check_contract_head_format(self, head):
        if config.CONTRACT_START_FLAG in head[0] and len(head) == 3:
            return True
        Logger.warn("The format of contract's head is wrong!")
        return False

    def _check_contract_content_format(self, content):
        i = 0
        while i < len(content):
            if (config.CONTRACT_FLAG_LEFT not in content[i] and config.CONTRACT_FLAG_RIGHT not in content[i]) or \
                   (config.MESSAGE_FLAG not in content[i + 1]):
                Logger.warn("The format of contract's content is wrong!")
                return False
            i += 2
        return True

    def _check_contract_tail_format(self, tail):
        if config.CONTRACT_END_FLAG in tail[0] and len(tail) == 1:
            return True
        Logger.warn("The format of contract's tail is wrong!")
        return False

    def _check_contract_format(self, head, content, tail):
        if self._check_contract_head_format(head) and self._check_contract_content_format(content) and \
                self._check_contract_tail_format(tail):
            return True
        return False

    def _write_head(self, head, fp):
        for i in range(len(head)):
            fp.write(head[i])
        fp.write('\n')

    def _content_filter(self, content, serviceName):
        contentFilter = []
        for i in range(0, len(content), 2):
            for j in range(len(serviceName)):
                if serviceName[j] in content[i]:
                    contentFilter.append(content[i])
                    contentFilter.append(content[i + 1])
                    break
        return contentFilter

    def _content_replace(self, contentFilter, serviceName):
        for i in range(0, len(contentFilter), 2):
            for j in range(len(serviceName)):
                regex = re.compile(serviceName[j])
                contentFilter[i] = regex.sub('FAKE_%s' % serviceName[j], contentFilter[i])

    def _write_content(self, content, serviceName, fp):
        contentFilter = self._content_filter(content, serviceName)
        self._content_replace(contentFilter, serviceName)
        for content in contentFilter:
            fp.write(content)

    def _write_tail(self, tail, fp):
        fp.write(tail[0])

    def _write_result(self, serviceName, head, content, tail):
        newFilePath = '{0}/../../output/{1}'.format(os.path.dirname(__file__), config.OUTPUT_FILE_NAME)
        with open(newFilePath, 'w') as fp:
            self._write_head(head, fp)
            self._write_content(content, serviceName, fp)
            self._write_tail(tail, fp)

    def _store_file(self):
        timeStamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        originalFilePath = '{0}/../../output/{1}'.format(os.path.dirname(__file__), config.OUTPUT_FILE_NAME)
        copyFilePath = '{0}/../../output/{1}.wsd'.format(os.path.dirname(__file__), timeStamp)
        shutil.copy(originalFilePath, copyFilePath)
        return copyFilePath

    def transfer_data(self, serviceNameList):
        fileContents = self._read_file(self._inputFileName)
        head, content, tail = self._split_file(fileContents)
        if self._check_contract_format(head, content, tail) and self._check_input_service_name(serviceNameList):
            self._write_result(serviceNameList, head, content, tail)
            return self._store_file()
        return None

if __name__ == '__main__':
    inputFileName = sys.path[1] + "/input/attach.wsd"
    print inputFileName
    DataTransferer(inputFileName).transfer_data(['BPF', 'STS'])
