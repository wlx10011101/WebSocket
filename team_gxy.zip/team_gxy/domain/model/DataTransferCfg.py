# -*- coding: utf-8 -*-
'''
Created on 2018年1月12日

@author: 10140129
'''


class DataTransferCfg(object):
    CONTRACT_FILE_PATH = '/input/attach.wsd'
    CONTRACT_START_FLAG = '@startuml'
    CONTRACT_END_FLAG = '@enduml'
    CONTRACT_FLAG_LEFT = '<'
    CONTRACT_FLAG_RIGHT = '>'
    MESSAGE_FLAG = 'note'
    OUTPUT_FILE_NAME = 'output.wsd'
    ALL_SERVICE_NAME = ['BPF', 'UC', 'GAS', 'HRRM', 'STS']
