# -*- coding: utf-8 -*-
'''
Created on 20160116

@author: 10154402
'''
import logging
import os
import json
from logging import DEBUG
from logging.handlers import RotatingFileHandler


log_file = os.path.abspath(os.path.dirname(__file__) + '../../log/log')
if not os.path.exists(log_file):
    f = open(log_file, 'w')
    f.close()

rthandler = RotatingFileHandler(log_file,
                                maxBytes=10 * 1024 * 1024,
                                backupCount=5)

rthandler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s')
rthandler.setFormatter(formatter)
logging.getLogger('').addHandler(rthandler)

console = logging.StreamHandler()
console.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(name)-1s: %(levelname)-8s %(message)s')
console.setFormatter(formatter)
logging.getLogger('').addHandler(console)
logging.getLogger('').setLevel(DEBUG)
logger = logging


def __log(t, msg, isFormatToJson=True):
    try:
        if not isFormatToJson:
            return t(msg)
        jsonDumpsINdentStr = json.dumps(msg, indent=1)
        return t(os.linesep + jsonDumpsINdentStr + os.linesep * 2)
    except Exception, e:
        logger.error(e)
        logger.error('Msg must be json format')


def debug(msg, isFormatToJson=False):
    return __log(logger.debug, msg, isFormatToJson)


def error(msg, isFormatToJson=False):
    return __log(logger.error, msg, isFormatToJson)


def info(msg, isFormatToJson=False):
    return __log(logger.info, msg, isFormatToJson)


def warn(msg, isFormatToJson=False):
    return __log(logger.warn, msg, isFormatToJson)
