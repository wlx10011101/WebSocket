# -*- coding: utf-8 -*-

import os
import sys
import unittest

from service.DataTransferService import DataTransferService


class ContractTest(unittest.TestCase):

    def setUp(self):
        self._testcasePath = os.path.dirname(__file__)
        self._inputFilePath = self._testcasePath + "/attach.wsd"

    def _compare_two_file_content(self, filePath1, filePath2):
        fileContent1, fileContent2 = "", ""
        with open(filePath1, 'r') as f1:
            fileContent1 = f1.read()
        with open(filePath2, 'r') as f2:
            fileContent2 = f2.read()
        return fileContent1 == fileContent2

    def test_one_service_normal_process(self):
        serviceNames = ['BPF']
        expectFileName = "expect_one_service_normal.wsd"
        outputFileName = DataTransferService.transfer_data(self._inputFilePath, serviceNames)
        self.assertTrue(self._compare_two_file_content(outputFileName, expectFileName),
                        "one service test failed,预期和实际内容不一致")

    def test_two_service_normal_process(self):
        serviceNames = ['BPF', 'STS']
        expectFileName = "expect_two_service_normal.wsd"
        outputFileName = DataTransferService().transfer_data(self._inputFilePath, serviceNames)
        self.assertTrue(self._compare_two_file_content(outputFileName, expectFileName),
                        "two service test failed,预期和实际内容不一致")

    def test_five_service_normal_process(self):
        serviceNames = ['BPF', 'STS', 'UC', 'GAS', "HRRM"]
        expectFileName = "expect_five_service_normal.wsd"
        outputFileName = DataTransferService.transfer_data(self._inputFilePath, serviceNames)
        self.assertTrue(self._compare_two_file_content(outputFileName, expectFileName),
                        "five service test failed,预期和实际内容不一致")

    def test_input_not_exist_service(self):
        serviceNames = ['BPF', 'STA']
        outputFileName = DataTransferService.transfer_data(self._inputFilePath, serviceNames)
        self.assertEqual(outputFileName, None,
                        "contain not exist service,not return None")

    def test_check_abnomal_contract_head(self):
        serviceNames = ['BPF', 'STS']
        inputFilePath = self._testcasePath + "/input_contract_abnormal_head.wsd"
        outputFileName = DataTransferService.transfer_data(inputFilePath, serviceNames)
        print outputFileName
        self.assertEqual(outputFileName, None,
                        "contract format abnomal head,but not return None")

    def test_check_abnomal_contract_body(self):
        serviceNames = ['BPF', 'STS']
        inputFilePath = self._testcasePath + "/input_contract_abnormal_boby.wsd"
        outputFileName = DataTransferService.transfer_data(inputFilePath, serviceNames)
        self.assertEqual(outputFileName, None,
                        "contract format abnomal body,but not return None")

    def test_check_abnomal_contract_tail(self):
        serviceNames = ['BPF', 'STS']
        inputFilePath = self._testcasePath + "/input_contract_abnormal_tail.wsd"
        outputFileName = DataTransferService.transfer_data(inputFilePath, serviceNames)
        self.assertEqual(outputFileName, None,
                        "contract format abnomal tail,but not return None")

    def tearDown(self):
        pass


if __name__ == '__main__':
    unittest.main()
