# coding:utf-8
'''
Created on 2018年1月20日

@author: 10111815
'''

import os
import sys

sys.path.append(os.path.abspath('%s//..' % sys.path[0]))

from domain.model.DataTransferer import DataTransferer
from infrastructure.log import Logger


class DataTransferService():

    @staticmethod
    def transfer_data(inputFileName, serviceNameList):
        return DataTransferer(inputFileName).transfer_data(serviceNameList)


if __name__ == '__main__':
    if len(sys.argv) != 3:
        Logger.error("must be 2 args") 
        sys.exit()
    inputFileName = sys.argv[1]
    if not os.path.exists(inputFileName):
        Logger.error("file:{0} not exist".format(inputFileName))
        sys.exit()
    serviceNameList = sys.argv[2].split(",")
    DataTransferService.transfer_data(inputFileName, serviceNameList)
    print "Transfer file successful"
