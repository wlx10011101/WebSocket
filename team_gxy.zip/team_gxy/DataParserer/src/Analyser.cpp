#include "Analyser.h"
#include "DataLoader.h"
#include <iostream>
#include <Util.h>
#include <Message.h>


const int FIRSTELEMENT = 0;

string Analyser::GetSubscribeInfo(int subParam)
{
    string scribeInfoTmp;
    string scribeInfo;
    vector<Message> vMsg;

    vMsg = PublishMsgInfo();
    for(int i=0;i < vMsg.size();i++)
    {
        scribeInfoTmp = vMsg[i].getPropertyValue(subParam);
        if(scribeInfo.find(scribeInfoTmp+"\n") == string::npos)
        {
        scribeInfo += scribeInfoTmp;
        scribeInfo += "\n";
        }
    }
    cout<<"\nsubscribe info:"<<endl;
    cout<<scribeInfo;
    return scribeInfo;
}

string Analyser::GetFakeProcess()
{
    vector<Message> vMsg;
    string fakeProcess;

    vMsg = PublishMsgInfo();
    cout << "\nfake process info:" << endl;
    fakeProcess += GetActivityModel(vMsg);
    fakeProcess+= GetProcess(vMsg);
    return fakeProcess;
}

string Analyser::GetProcess(vector<Message> vMsg)
{
    string strProcessInfo;
    string operate;
    string leftModelValue;
    string rightModelValue;
    string arrowValue;
    const int MSGPARAMCOUNT = MSGHEADPARAMCOUNT+MSGBODYPARAMCOUNT;

    for(int i = 0;i < vMsg.size();i++)
    {
        leftModelValue = vMsg[i].getPropertyValue(leftModel);
        rightModelValue = vMsg[i].getPropertyValue(rightModel);
        arrowValue = vMsg[i].getPropertyValue(arrow);

        if (((leftModelValue.find(FAKE) != string::npos) && (arrowValue.find(RIGHTARROW) != string::npos)) ||
            ((rightModelValue.find(FAKE) != string::npos) && (arrowValue.find(LEFTARROW) != string::npos)))
        {
            operate = "Send";
        }else
        {
            operate = "Wait";
        }
        strProcessInfo += to_string(i+1)+")     ";
        strProcessInfo += operate +" " + vMsg[i].getPropertyValue(msgName)+"(";
        for(int j= MSGHEADPARAMCOUNT+1; j<MSGPARAMCOUNT-1; j++)
        {
            strProcessInfo += vMsg[i].getPropertyValue(j);
            strProcessInfo += "-";
        }
        strProcessInfo += vMsg[i].getPropertyValue(MSGPARAMCOUNT-1) + ")\n";
    }
    cout <<strProcessInfo<<endl;
    return strProcessInfo;

}

string Analyser::GetActivityModel(vector<Message> vMsg)
{
    string leftModelValue = vMsg[FIRSTELEMENT].getPropertyValue(leftModel);
    string rightModelValue = vMsg[FIRSTELEMENT].getPropertyValue(rightModel);

    if(leftModelValue.find(FAKE) != string::npos)
    {
        cout<<"����ģʽ(active)��"<<endl;
        return "����ģʽ(active)��\n";
    }
    else if (rightModelValue.find(FAKE) != string::npos)
    {
        cout<<"����ģʽ(passivity)��"<<endl;
        return "����ģʽ(passivity)��\n";
    }
    else
    {
        cout<<"print activity model error!!";
        exit(1);
    }
}

Message Analyser::PushMsgPropertyValue(string &strMsg)
{
    vector<string> vMsgStruct;
    vector<string> vMsgBody;
    Message msg;

    int indexBefore = 0;
    int indexAfter = strMsg.find('\n');
    string strMsgHead = strMsg.substr(indexBefore, indexAfter);
    string strMsgBody = strMsg.substr(indexAfter, strMsg.length()-1);

    vMsgStruct=Util::getMatchStringVector(strMsgHead, MSGHEADPATTERN,MSGHEADPARAMCOUNT);
    vMsgBody=Util::getMatchStringVector(strMsgBody, MSGBODYPARTTERN,MSGBODYPARAMCOUNT);
    vMsgStruct.insert(vMsgStruct.end(),vMsgBody.begin(),vMsgBody.end());
    for (unsigned int i =0;i<vMsgStruct.size();i++)
    {
        msg.setPropertyValue(vMsgStruct[i]);
    }
    return msg;
}

vector<Message> Analyser::PublishMsgInfo()
{
    FileLoader fileLoader;
    vector<Message> vMsg;

    DataLoader *dataLoder = &fileLoader;
    vector<string> vStrMsg = dataLoder->loadData();

    for (unsigned int i =0;i<vStrMsg.size();i++)
    {
        string strMsg = vStrMsg[i];
        vMsg.push_back(PushMsgPropertyValue(strMsg));
    }
    return vMsg;
}

