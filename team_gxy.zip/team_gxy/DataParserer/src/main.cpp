#include <getopt.h>
#include <Analyser.h>
#include <Util.h>
#include <test.h>
#include <DataLoader.h>
#include <stdlib.h>
int subscribeParam;
bool runTestcase=false;

bool checkOption(int argc, char* argv[])
{
    char option;
    bool result = true;
    while((option = getopt(argc, argv, "s:th")) != -1)
    {
        switch(option)
        {
            case 's':
                subscribeParam = atoi(optarg);
                break;
            case 't':
                runTestcase = true;
                break;
            default:
                cout<<"Usage: DataParser.exe [options] file"<<endl;
                cout<<"where options include:"<<endl;
                cout<<"\t-s\t To print fake subscribe session"<<endl;
                cout<<"\t-t\t To excute testcase"<<endl;
                cout<<"\t-h\t To print help"<<endl;
                result = false;
                break;
        }
    }
    return result;
}

int main(int argc, char *argv[])
{
    if(!checkOption(argc, argv))
    {
        cout << "Error use DataParser. ";
        exit(1);
    }
    Analyser analyser;
    if(runTestcase)
    {
        Test test;
        test.testGetSessionInfo();
        test.testBasicGetFakeProcess();
        test.testGetKeyParamInfo();
        test.testGetMsgNameInfo();
        return 0;
    }
    if (subscribeParam)
    {
        analyser.GetSubscribeInfo(subscribeParam);
    }
    else
    {
        analyser.GetSubscribeInfo(session);
    }
    analyser.GetFakeProcess();
    return 0;


}
