#ifndef ANALYSER_H
#define ANALYSER_H
#include <string>
#include <iostream>
#include <vector>
#include "Message.h"
using namespace std;
class Analyser
{
    public:

        string GetSubscribeInfo(int subParam);
        string GetFakeProcess();
        Message PushMsgPropertyValue(string &strMsg);
        vector<Message> PublishMsgInfo();
        string GetActivityModel(vector<Message> vMsg);
        string GetProcess(vector<Message> vMsg);

    protected:

    private:
};

#endif // ANALYSER_H
