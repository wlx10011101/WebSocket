#ifndef TEST_H
#define TEST_H
#include <assert.h>
#include <Analyser.h>

using namespace std;
class Test
{
    public:
        void testGetSessionInfo();
        void testBasicGetFakeProcess();
        void testGetKeyParamInfo();
        void testGetMsgNameInfo();
        void testHRRMSTSGetFakeProcess();

    protected:

    private:
};

#endif // TEST_H
