void str_copy(char *dest, char *src);
