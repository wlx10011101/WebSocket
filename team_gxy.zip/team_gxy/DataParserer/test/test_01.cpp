#include <test.h>

Analyser analyser;
void Test::testGetSessionInfo()
{
    string subscribeinfo = analyser.GetSubscribeInfo(session);
    assert(subscribeinfo.find("BC_CCCH")!=string::npos);
    assert(subscribeinfo.find("UCS_STS_SRB")!=string::npos);
    assert(subscribeinfo.find("BC_UE")!=string::npos);
    assert(subscribeinfo.find("UCS_CMS_UE")!=string::npos);
};

void Test::testGetKeyParamInfo()
{
    string subscribeinfo = analyser.GetSubscribeInfo(key);
    assert(subscribeinfo.find("scene.gnbId.cellId.crnti")!=string::npos);
    assert(subscribeinfo.find("cpfueid")!=string::npos);
    assert(subscribeinfo.find("gnbId.cellId.cpfueid")!=string::npos);
};

void Test::testGetMsgNameInfo()
{
    string subscribeinfo = analyser.GetSubscribeInfo(msgName);
    assert(subscribeinfo.find("RRCConnectionRequest")!=string::npos);
    assert(subscribeinfo.find("SrbAdmitReques")!=string::npos);
    assert(subscribeinfo.find("UeContextConfigRequest")!=string::npos);
    assert(subscribeinfo.find("SrbAdmitResponse")!=string::npos);
    assert(subscribeinfo.find("UeContextConfigResponse")!=string::npos);
    assert(subscribeinfo.find("RRCConnectionSetUpComplete")!=string::npos);
};

void Test::testBasicGetFakeProcess()
{
    string fakeProcess = analyser.GetFakeProcess();
    assert(fakeProcess.find("active")!=string::npos);
    assert(fakeProcess.find("1)     Send RRCConnectionRequest(BC_CCCH-1-scene.gnbId.cellId.crnti)")!=string::npos);
    assert(fakeProcess.find("2)     Wait SrbAdmitReques(UCS_STS_SRB-1-cpfueid)")!=string::npos);
    assert(fakeProcess.find("3)     Wait UeContextConfigRequest(BC_UE-1-gnbId.cellId.cpfueid)")!=string::npos);
    assert(fakeProcess.find("4)     Send SrbAdmitResponse(UCS_STS_SRB-2-cpfueid)")!=string::npos);
    assert(fakeProcess.find("5)     Send UeContextConfigResponse(BC_UE-2-gnbId.cellId.cpfueid)")!=string::npos);
    assert(fakeProcess.find("6)     Wait UeContextConfigRequest(BC_CCCH-2-scene.gnbId.cellId.crnti)")!=string::npos);
    assert(fakeProcess.find("7)     Send RRCConnectionSetUpComplete(BC_DCCH--cpfUeId.ppsId)")!=string::npos);
    assert(fakeProcess.find("8)     Send RRCConnectionSetUpComplete(UCS_CMS_UE-2-gnbId.cellId.cpfueid)")!=string::npos);
};

void Test::testHRRMSTSGetFakeProcess()
{
    string fakeProcess = analyser.GetFakeProcess();
    assert(fakeProcess.find("passivity")!=string::npos);
    assert(fakeProcess.find("1)     Wait SrbAdmitReques(UCS_CMS_UE-1-gnbId.cellId.cpfueid)")!=string::npos);
    assert(fakeProcess.find("2)     Send SrbAdmitResponse(UCS_CMS_UE-2-gnbId.cellId.cpfueid)")!=string::npos);
    assert(fakeProcess.find("3)     Wait SrbAdmitReques(UCS_STS_SRB-1-cpfueid)")!=string::npos);
    assert(fakeProcess.find("4)     Send SrbAdmitResponse(UCS_STS_SRB-2-cpfueid)")!=string::npos);
    assert(fakeProcess.find("5)     Wait RRCConnectionSetUpComplete(BC_DCCH--cpfUeId.ppsId)")!=string::npos);
    assert(fakeProcess.find("6)     Send RRCConnectionSetUpComplete(UCS_CMS_UE-2-gnbId.cellId.cpfueid)")!=string::npos);
    assert(fakeProcess.find("7)     Wait SrbAdmitAcknowledge(UCS_CMS_UE-3-gnbId.cellId.cpfueid)")!=string::npos);
};
