#ifndef UMLPARSER_H_INCLUDED
#define UMLPARSER_H_INCLUDED

#include "skin_params.h"
#include "handovers.h"
#include "error_stack.h"
#include <fstream>

using namespace std;

class UmlParser
{
private:
    SkinParams *skinParams;
    Handovers *handovers;
    const string STARTUML = "@startuml";
    const string ENDUML = "@enduml";
public:
    UmlParser ()
    {
        handovers = new Handovers();
    }

    bool parse(string filePath)
    {
        char buffer[256];
        ifstream wsdFile(filePath);
        bool recordStart = false;
        bool recordEnd = false;
        bool handoverStart = false;

        vector<string> config;
        vector<string> handoverBlock;

        if (! wsdFile.is_open())
        {
            ErrorStack::push_error(START_POINT, "OPEN FILE ERROR");
            return false;
        }
        clear_node_graph_sequence();
        ErrorStack::line_num_clear();
        while (! wsdFile.eof())
        {
            ErrorStack::line_num_increment();
            wsdFile.getline(buffer, 100);
            if (startsWithSymbolAnd(string(buffer)))
            {
                recordStart = true;
                continue;
            }
            if (endsWithSymbolAnd(string(buffer)))
            {
                handovers->add_handover_block_object(HandoverBlock(handoverBlock));
                recordEnd = true;
                break;
            }
            if (recordStart)
            {
                if (isSkinConfigure(string(buffer)))
                {
                    config.push_back(string(buffer));
                    continue;
                }
                if (is_handover_message(string(buffer)))
                {
                    handoverStart = true;
                    if (! handoverBlock.empty())
                    {
                        handovers->add_handover_block_object(HandoverBlock(handoverBlock));
                        handoverBlock.clear();
                    }
                    handoverBlock.push_back(string(buffer));
                }
                else
                {
                    if (handoverStart) {
                        handoverBlock.push_back(string(buffer));
                    }

                }
            }
        }
        skinParams = new SkinParams(config);
        wsdFile.close();
        if(!recordStart){
            ErrorStack::push_error(START_POINT, "Not Find @STARTUML.");
        }
        if(!recordEnd){
             ErrorStack::push_error(ErrorStack::get_line_num(), "Not Find @ENDUML.");
        }
        return true;
    }

    SkinParams get_skin_params ()
    {
        return *skinParams;
    }

    Handovers get_handovers ()
    {
        return *handovers;
    }

    void fake(vector<string> fakedNodes) {
        handovers->fake(fakedNodes);

    }

    void write_to_file (string outputFilePath="")
    {
        std::ofstream wsdFile(outputFilePath);
        if (!wsdFile) {
            cout << "open file error" << endl;
            return;
        }
        write_file(wsdFile, STARTUML);
        write_file(wsdFile, skinParams->get_params());
        write_file(wsdFile, "");
        write_file(wsdFile, handovers->print());
        write_file(wsdFile, ENDUML);
        wsdFile.close();
        return;
    }

    void write_to_cmd() {
        cout << STARTUML <<endl;
        print_vector(skinParams->get_params());
        cout << endl;
        print_vector(handovers->print());
        cout << ENDUML <<endl;
    }

private:

    void clear_node_graph_sequence() {
        NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
        nodeGraphicSequence->clear();
    }

    void write_file(ofstream &file, vector<string> records) {
        for (unsigned int i = 0; i < records.size(); i++) {
            file << records[i] << endl;
        }
    }

    void write_file(ofstream &file, string singleLine) {
        file << singleLine << endl;
    }

    void print_vector (vector<string> records) {
        for (unsigned int i = 0; i < records.size(); i++) {
            cout << records[i] << endl;
        }
    }

    bool startsWithSymbolAnd(string target)
    {
        return RegexUtil::reg_match(target, "^@startuml$");
    }

    bool endsWithSymbolAnd(string target)
    {
        return RegexUtil::reg_match(target, "^@enduml$");
    }

    bool isSkinConfigure(string target)
    {
        return RegexUtil::reg_match(target, "skinparam[\\s\\S]+");
    }

    bool is_handover_message(string msg)
    {
        return RegexUtil::reg_search(msg, "[<>]");
    }
};

#endif // UMLPARSER_H_INCLUDED
