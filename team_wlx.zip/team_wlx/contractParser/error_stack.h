#ifndef ERROR_STACK_H_INCLUDED
#define ERROR_STACK_H_INCLUDED
#include <vector>

class ErrorStack
{
public:
    static ErrorStack *getInstance();
    int lineNum=0;
    ~ErrorStack() { errors.clear(); }
    static void push_error(string description);
    static bool is_error_exit();
    static vector<string> pop_all_error();
    static void line_num_increment();
    static void line_num_clear();
    static string get_line_num_str();

private:
    vector<string> errors;
    static ErrorStack* instance;
    ErrorStack();
    ErrorStack(const ErrorStack&);
	ErrorStack& operator=(const ErrorStack&);
};

ErrorStack* ErrorStack::instance = new ErrorStack();

ErrorStack::ErrorStack(){}

ErrorStack::ErrorStack(const ErrorStack&){}

ErrorStack& ErrorStack::operator=(const ErrorStack&){}

ErrorStack* ErrorStack::getInstance(){
	return instance;
}

void ErrorStack::push_error(string description){
   getInstance()->errors.push_back(description);
}

bool ErrorStack::is_error_exit(){
    return getInstance()->errors.size()>0;
}


vector<string> ErrorStack::pop_all_error(){
    return getInstance()->errors;
}

void ErrorStack::line_num_increment(){
    getInstance()->lineNum = getInstance()->lineNum+1;
}

void ErrorStack::line_num_clear(){
    getInstance()->lineNum=0;
}

string ErrorStack::get_line_num_str(){
    return to_string(getInstance()->lineNum);
}
#endif // ERROR_STACK_H_INCLUDED
