#ifndef NODE_H_INCLUDED
#define NODE_H_INCLUDED

#include <string>
#include "string_util.h"
#include "note_message.h"
using namespace std;

class Node
{

private:
    string name;
    NoteMessage *noteMessages;
    bool isFake;
    bool isSource;
    bool isTarget;
public:
    Node(string name, bool isFake, bool isSource, bool isTarget);
    ~Node();
    string get_name() { return name; }
    string get_fake_name();
    bool has_note_message() { return noteMessages != nullptr; }
    string get_note_messages_string (){ return noteMessages->dump(); }
    NoteMessage* get_note_messages() { return noteMessages; }
    void set_attr_note_message(string message){ Node::noteMessages = new NoteMessage(message); }
    bool is_fake(){ return isFake; }
    bool is_source(){ return isSource; }
    bool is_target(){ return isTarget; }
    void set_attr_is_fake(bool isFake){ Node::isFake = isFake; }
    void set_attr_is_source(bool isSource){ Node::isSource = isSource; }
    void set_attr_is_target(bool isTarget){ Node::isTarget = isTarget; }
    string get_sessions();

};

Node::Node (string name, bool isFake=false, bool isSource=false, bool isTarget=false)
{
    Node::name = name;
    Node::isSource = isSource;
    Node::isTarget = isTarget;
    Node::isFake = isFake;
    noteMessages = nullptr;
}

Node::~Node (){
    delete noteMessages;
}

string Node::get_fake_name ()
{
    if (isFake){
        return StringUtil::fake(name);
    }else{
        return name;
    }
    return "";
}

string Node::get_sessions() {
    if (noteMessages != nullptr){
        return noteMessages->get_session();
    }
    return "";
}

#endif // NODE_H_INCLUDED
