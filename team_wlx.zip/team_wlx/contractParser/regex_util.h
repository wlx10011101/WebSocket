#ifndef REGEX_UTIL_H_INCLUDED
#define REGEX_UTIL_H_INCLUDED

#include <regex>

class RegexUtil {

public:
    static bool reg_search (string target, string regExpression)
    {
        regex re(regExpression);
        smatch m;
        return regex_search(target, m, re);
    }

    static void reg_search (string target, string regExpression, smatch &result)
    {
        regex re(regExpression);
        regex_search(target, result, re);
    }

    static string reg_replace (string target, string regExpression, string replaceString) {
        regex reg(regExpression);
        return regex_replace(target, reg, replaceString);
    }

    static bool reg_match (string target, string regExpression)
    {
        regex re(regExpression);
        return regex_match(target, re);
    }
};

#endif // REGEX_UTIL_H_INCLUDED
