#ifndef HANDOVERS_H_INCLUDED
#define HANDOVERS_H_INCLUDED

#include <iostream>
#include <vector>
#include "handover_block.h"

using namespace std;

class Handovers {
private:
    vector<HandoverBlock> handovers;
public:
    Handovers(){}
    ~Handovers() {handovers.clear();}
    vector<string> print();
    void fake(vector<string> fakedNodes);
    void get_subscribe_sessions();
    void print_fake_flow();
    void add_handover_block_object(HandoverBlock block);
    vector<string> get_node_sequence();
    vector<HandoverBlock> get_handover_blocks() { return handovers; }
};

void Handovers::fake(vector<string> fakedNodes){
     for (unsigned int i = 0; i < handovers.size(); i++) {
        handovers[i].fake(fakedNodes);
    }
}

vector<string> Handovers::print (){
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    nodeGraphicSequence->clear();
    vector<string> handoverPrint;
    for (unsigned int i = 0; i < handovers.size(); i++) {
        vector<string> blockPrint = handovers[i].print();
        handoverPrint.insert(handoverPrint.end(), blockPrint.begin(), blockPrint.end());
    }
    return handoverPrint;
}

void Handovers::get_subscribe_sessions(){
    cout<<"FAKE SUBSCRINE"<<endl;
    for (unsigned int i = 0; i < handovers.size(); i++) {
        string subsribeFakeMessage = handovers[i].get_subscribe_sessions();
        if (subsribeFakeMessage != "")
            cout<< subsribeFakeMessage <<endl;
    }
}

void Handovers::print_fake_flow (){
    for (unsigned int i = 0; i < handovers.size(); i++) {
        cout << handovers[i].get_fake_messages() << endl;
    }
}

void Handovers::add_handover_block_object(HandoverBlock block) {
    vector<string> nodeNames = block.get_ordered_node_name();
    NodeGraphicSequence *nodeSequence = NodeGraphicSequence::getInstance();
    for (unsigned int i = 0; i < nodeNames.size(); i++) {
        nodeSequence->add_node(nodeNames[i]);
    }
    handovers.push_back(block);
}

vector<string> Handovers::get_node_sequence() {
    NodeGraphicSequence *nodeSequence = NodeGraphicSequence::getInstance();
    return nodeSequence->get_node_sequence();
}

#endif // HANDOVERS_H_INCLUDED
