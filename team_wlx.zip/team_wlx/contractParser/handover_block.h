
#ifndef HANDOVER_BLOCK_H_INCLUDED
#define HANDOVER_BLOCK_H_INCLUDED

#define NOFAKE 0
#define FAKEBOUNDARY 1
#define ALLFKAE 2

#define START_POINT 0
#define TWO_PART 2
#define TRIPARTITE 3

#define SOURCE_NODE 0
#define TARGET_NODE 1

#include <iostream>
#include <vector>
#include "node.h"
#include "string_util.h"
#include "regex_util.h"
#include "node_graphic_sequence.h"


using namespace std;

class HandoverBlock
{
public:
    vector<Node*> orderedNode;
    string symbol;
    string message;
    bool isFakeBoundary=false;

public:
    HandoverBlock(vector<string> handoverBlock);
    ~HandoverBlock();
    vector<string> get_ordered_node_name (bool isFake);
    void fake(vector<string> fakeNodeList);
    vector<string> print();
    string get_subscribe_sessions();
    string get_fake_messages();

private:
    void parse_note (string noteKey, string noteMessage, int lineNum);
    string get_node_name(string head, bool isEnd, int lineNum);
    string symbol_string(string head, int lineNum);
    bool is_fake(string nodeName);
    bool is_symbol_chart(char chart);

    string get_no_fake_name(string nodeName);
    vector<string> get_note_key_sequence(vector<string> orderedNodeName);
    Node* get_node(int whichNode);
    void parse_head_handover_direction(string direction, int lineNum);
    unsigned int get_symbol_start_index(string head, bool isReverse);

    bool is_graphic_left_right_note (string noteKey, bool isReverse, int lineNum);
};

HandoverBlock::HandoverBlock(vector<string> handoverBlocks){
    int startLineNum = ErrorStack::get_line_num() - handoverBlocks.size();
    for (unsigned int i=0; i<handoverBlocks.size();i++){
        vector<string> temp = StringUtil::split(handoverBlocks[i], ":");
        StringUtil::trim(temp);
        if(i == START_POINT){
            if(temp.size()!=TWO_PART){
                ErrorStack::push_error(startLineNum+i, "Message Error");
                return;
            }
            parse_head_handover_direction(temp[0], startLineNum);
            message = temp[1];
        }else{
            if(temp.size() != TWO_PART){
                ErrorStack::push_error(startLineNum+i, "Note Error, lost note");
                return;
            }
            parse_note(temp[0], temp[1], startLineNum+i);
        }
    }
    if(orderedNode[0]->is_fake() ^ orderedNode[1]->is_fake()){
            isFakeBoundary=true;
        }else{
            isFakeBoundary=false;
        }
}

void HandoverBlock::parse_head_handover_direction(string direction, int lineNum){
    vector<string> result;
    symbol = symbol_string(direction, lineNum);
    vector<string> nodeName;
    nodeName.push_back(get_node_name(direction, false, lineNum));
    nodeName.push_back(get_node_name(direction, true, lineNum));
    NodeGraphicSequence::add_node(nodeName);
    vector<bool> sourceOrTarget;
    if (RegexUtil::reg_search(symbol, ">"))
    {
        sourceOrTarget = {true, false};
    }
    else
    {
        sourceOrTarget = {false, true};
    }
    for (unsigned int i=0; i<nodeName.size(); i++){
        orderedNode.push_back(new Node(get_no_fake_name(nodeName[i]), is_fake(nodeName[i]), sourceOrTarget[0], sourceOrTarget[1]));
    }

}
HandoverBlock::~HandoverBlock()
{
    orderedNode.clear();
}

vector<string> HandoverBlock::get_ordered_node_name (bool isFake=false)
{
    vector<string>result;
    for (unsigned i = 0; i < orderedNode.size(); i++){
        if (isFake){
            result.push_back(orderedNode[i]->get_fake_name());
        }else{
            result.push_back(orderedNode[i]->get_name());
        }
    }
    return result;
}

void HandoverBlock::parse_note (string noteKey, string noteMessage, int lineNum)
{
    if (is_graphic_left_right_note(noteKey, false, lineNum)){
        orderedNode[1]->set_attr_note_message(noteMessage, lineNum);
    }
    if (is_graphic_left_right_note(noteKey, true, lineNum)){
        orderedNode[0]->set_attr_note_message(noteMessage, lineNum);
    }
}

string HandoverBlock::get_node_name(string head, bool isEnd, int lineNum)
{
    string temp;
    if(isEnd){
        temp = StringUtil::slice(head, get_symbol_start_index(head, isEnd), head.size());
    }else{
        temp = StringUtil::slice(head, START_POINT, get_symbol_start_index(head, isEnd));
    }

    StringUtil::trim(temp);
    if(StringUtil::is_space_in_string(temp)){
        ErrorStack::push_error(lineNum, "Node Error");
    }
    return temp;
}

bool HandoverBlock::is_fake(string nodeName)
{
    return RegexUtil::reg_search(nodeName, "FAKE_(.+)");
}
string HandoverBlock::get_no_fake_name(string nodeName)
{
    smatch r1;
    RegexUtil::reg_search(nodeName, "FAKE_(.+)", r1);
    if (r1.size() > 0)
    {
        return r1[1];
    }
    else
    {
        return nodeName;
    }
}
string HandoverBlock::symbol_string(string head, int lineNum)
{
    string temp = StringUtil::slice(head, get_symbol_start_index(head, false), get_symbol_start_index(head, true));
    StringUtil::trim(temp);
    if(RegexUtil::reg_search(temp, "[^-><]")|| RegexUtil::reg_search(temp, "<.+>"))
    {
        ErrorStack::push_error(lineNum, "Symbol Error");
    }
    return temp;
}

unsigned int HandoverBlock::get_symbol_start_index(string head, bool isReverse)
{
    const int scale = head.size();
    unsigned int temp = isReverse ? scale : START_POINT;
    unsigned int index;
    for (unsigned int i = 0; i < head.size(); i++)
    {
        index= isReverse ? (scale-i) : i;
        if (is_symbol_chart(head[index]))
        {
            return isReverse ? index+1: index;
        }
    }
    return temp;
}

bool HandoverBlock::is_symbol_chart(char chart){
    return (chart == '-' || chart == '>' || chart == '<');
}

bool HandoverBlock::is_graphic_left_right_note (string noteHead, bool isReverse, int lineNum)
{
    if(RegexUtil::reg_search(noteHead,"[^(note right)|(note left)]"))
    {
        ErrorStack::push_error(lineNum, "Note Key error");
    }
    vector<string> orderedNodeName = get_ordered_node_name(true);
    vector<string> noteKeySequence;
    if (isReverse){
        noteKeySequence =  {"note left", "note right"};
    }else{
         noteKeySequence =  {"note right", "note left"};
    }
    return (NodeGraphicSequence::check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(noteHead, noteKeySequence[0])) ||
           (! NodeGraphicSequence::check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(noteHead, noteKeySequence[1]));
}

void HandoverBlock::fake(vector<string> fakeNodeList)
{
    int fakeTimes = 0;
    for (unsigned int i=0; i< orderedNode.size(); i++)
    {
        string nodeName = orderedNode[i]->get_name();
        if (StringUtil::is_in_list(nodeName,fakeNodeList))
        {
            orderedNode[i]->set_attr_is_fake(true);
            ++fakeTimes;
        }
    }
    if (fakeTimes == FAKEBOUNDARY)
    {
        HandoverBlock::isFakeBoundary=true;
    }
}

vector<string> HandoverBlock::print()
{
    vector<string> result;
    vector<string> noteKeyWord;
    if (isFakeBoundary)
    {
        string headTemp;
        vector<string> orderedNodeName = get_ordered_node_name(true);
        NodeGraphicSequence::add_node(orderedNodeName);
        vector<string> noteKeyWord = get_note_key_sequence(orderedNodeName);
        for (unsigned int i=0; i< orderedNode.size(); i++)
        {
            headTemp += orderedNode[i]->get_fake_name();
            if (i == 0)
            {
                headTemp += " " + symbol + " ";
            }
            if (orderedNode[i]->has_note_message())
            {
                result.push_back(noteKeyWord[i] + orderedNode[i]->get_note_messages_string());
            }
        }
        headTemp += " : " + message;
        result.insert(result.begin(), headTemp);
    }
    return result;
}

vector<string> HandoverBlock::get_note_key_sequence(vector<string> orderedNodeName){
    vector<string> noteKeyWord;
    if (NodeGraphicSequence::check_node_position(orderedNodeName[0], orderedNodeName[1]))
    {
         noteKeyWord = {"note left : ", "note right : "};
    }
    else
    {
         noteKeyWord = {"note right : ", "note left : "};
    }
    return noteKeyWord;
}

string HandoverBlock::get_subscribe_sessions()
{
    string result;
    if (isFakeBoundary)
    {
        Node* sourceNode = get_node(SOURCE_NODE);
        Node* targetNode = get_node(TARGET_NODE);
        if (targetNode->is_fake())
        {
            result = sourceNode->get_sessions();
        }
    }
    return result;
}

string HandoverBlock::get_fake_messages()
{
    Node* sourceNode = get_node(SOURCE_NODE);
    string result = "";
    if(isFakeBoundary)
    {
        if (sourceNode->is_fake())
        {
            result += "Send " + message;
        }
        else
        {
            result += "Wait " + message;
        }
        if(sourceNode->has_note_message())
        {
            result += "(" + sourceNode->get_note_messages()->get_session() + "-"
                      + sourceNode->get_note_messages()->get_event()  + "-"
                      + sourceNode->get_note_messages()->get_key()
                      + ")";
        }
    }
    return result;
}

Node* HandoverBlock::get_node(int whichNode)
{
    for (unsigned int i=0; i<orderedNode.size(); i++)
    {
        if (whichNode == SOURCE_NODE && orderedNode[i]->is_source()){
            return orderedNode[i];
        }
        if(whichNode == TARGET_NODE && orderedNode[i]->is_target()){
            return orderedNode[i];
        }
    }
    return nullptr;
}

#endif // HANDOVER_BLOCK_H_INCLUDED
