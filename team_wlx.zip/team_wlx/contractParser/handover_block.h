
#ifndef HANDOVER_BLOCK_H_INCLUDED
#define HANDOVER_BLOCK_H_INCLUDED

#define NOFAKE 0
#define FAKEBOUNDARY 1
#define ALLFKAE 2

#include <iostream>
#include <vector>
#include "node.h"
#include "string_util.h"
#include "regex_util.h"
#include "node_graphic_sequence.h"


using namespace std;

class HandoverBlock
{
public:
    vector<Node*> orderedNode;
    string symbol;
    string message;
    bool isFakeBoundary;

public:
    HandoverBlock(vector<string> handoverBlock);
    ~HandoverBlock();
    vector<string> get_ordered_node_name (bool isFake);
    void fake(vector<string> fakeNodeList);
    vector<string> print();
    string get_subscribe_sessions();
    string get_fake_messages();

private:
    vector<Node*> parse_head(string blockHead);
    void parse_note (vector<string> handoverBlock);
    string first_node_name(string head);
    string second_node_name(string head);
    string symbol_string(string head);
    bool is_fake(string nodeName);

    string get_no_fake_name(string nodeName);
    Node* get_target_node();
    Node* get_source_node();

    unsigned int get_symbol_start_index(string head);
    unsigned int get_symbol_end_index (string head);

    bool is_graphic_left_note (vector<string> orderedNodeName, string note_head);
    bool is_graphic_right_note (vector<string> orderedNodeName, string note_head);
};

HandoverBlock::HandoverBlock(vector<string> handoverBlock)
{
    HandoverBlock::orderedNode = parse_head(handoverBlock[0]);
    if (!ErrorStack::is_error_exit())
    {
        parse_note(handoverBlock);
        if(orderedNode[0]->is_fake() ^ orderedNode[1]->is_fake())
        {
            isFakeBoundary=true;
        }
        else
        {
            isFakeBoundary=false;
        }
    }
}

HandoverBlock::~HandoverBlock()
{
    orderedNode.clear();
}

vector<string> HandoverBlock::get_ordered_node_name (bool isFake=false)
{
    vector<string>result;
    for (unsigned i = 0; i < orderedNode.size(); i++)
    {
        if (isFake)
        {
            result.push_back(orderedNode[i]->get_fake_name());
        }
        else
        {
            result.push_back(orderedNode[i]->get_name());
        }
    }
    return result;
}

vector<Node*> HandoverBlock::parse_head(string blockHead)
{
    vector<Node*> orderedNode;
    vector<string> tmp = StringUtil::split(blockHead, ":");
    if(tmp.size()!=2)
    {
        ErrorStack::push_error("Before Line "+ ErrorStack::get_line_num_str()+": Message Error");
        return orderedNode;
    }
    StringUtil::trim(tmp);
    message = tmp[1];
    symbol = symbol_string(tmp[0]);
    string firstNodeName = first_node_name(tmp[0]);
    string secondNodeName = second_node_name(tmp[0]);
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    nodeGraphicSequence->add_node(firstNodeName);
    nodeGraphicSequence->add_node(secondNodeName);
    if (RegexUtil::reg_search(symbol, ">"))
    {
        orderedNode.push_back(new Node(get_no_fake_name(firstNodeName), is_fake(firstNodeName), true, false));
        orderedNode.push_back(new Node(get_no_fake_name(secondNodeName), is_fake(secondNodeName), false, true));
    }
    else
    {
        orderedNode.push_back(new Node(get_no_fake_name(firstNodeName), is_fake(firstNodeName), false, true));
        orderedNode.push_back(new Node(get_no_fake_name(secondNodeName), is_fake(secondNodeName), true, false));
    }
    return orderedNode;
}

void HandoverBlock::parse_note (vector<string> handoverBlock)
{
    vector<string> orderedNodeName = get_ordered_node_name(true);
    for (unsigned int i = 1; i < handoverBlock.size(); i++)
    {
        vector<string> tmp = StringUtil::split(handoverBlock[i], ":");
        if(tmp.size() != 2)
        {
            ErrorStack::push_error("Before Line "+ ErrorStack::get_line_num_str()+ ": Note Error, lost note");
            return;
        }
        StringUtil::trim(tmp);
        if (is_graphic_right_note(orderedNodeName, tmp[0]))
        {
            orderedNode[1]->set_attr_note_message(tmp[1]);
        }
        if (is_graphic_left_note(orderedNodeName, tmp[0]))
        {
            orderedNode[0]->set_attr_note_message(tmp[1]);
        }
    }
}

string HandoverBlock::first_node_name(string head)
{
    string tmp = "";
    for (unsigned int i = 0; i < get_symbol_start_index(head); i++)
    {
        tmp += head[i];
    }
    tmp = StringUtil::trim(tmp);
    if(StringUtil::is_space_in_string(tmp))
    {
        ErrorStack::push_error("Before Line "+ ErrorStack::get_line_num_str()+ ": First Node Error");
    }
    return tmp;
}

string HandoverBlock::second_node_name(string head)
{
    string tmp = "";
    for (unsigned int i = get_symbol_end_index(head) + 1; i < head.size(); i++)
    {
        tmp += head[i];
    }
    tmp = StringUtil::trim(tmp);
    if(StringUtil::is_space_in_string(tmp))
    {
        ErrorStack::push_error("Before Line "+ ErrorStack::get_line_num_str()+ ": Second Node Error");
    }
    return tmp;
}
bool HandoverBlock::is_fake(string nodeName)
{
    return RegexUtil::reg_search(nodeName, "FAKE_(.+)");
}
string HandoverBlock::get_no_fake_name(string nodeName)
{
    smatch r1;
    RegexUtil::reg_search(nodeName, "FAKE_(.+)", r1);
    if (r1.size() > 0)
    {
        return r1[1];
    }
    else
    {
        return nodeName;
    }
}
string HandoverBlock::symbol_string(string head)
{
    string tmp = "";
    for (unsigned int i = get_symbol_start_index(head); i <= get_symbol_end_index(head); i++)
    {
        tmp += head[i];
    }
    tmp = StringUtil::trim(tmp);
    if(RegexUtil::reg_search(tmp, "[^-\>\<]")||(RegexUtil::reg_search(tmp, "<") && RegexUtil::reg_search(tmp, ">")))
    {
        ErrorStack::push_error("Before Line "+ ErrorStack::get_line_num_str()+ ": Symbol Error");
    }
    return tmp;
}

unsigned int HandoverBlock::get_symbol_start_index(string head)
{
    for (unsigned int i = 0; i < head.size(); i++)
    {
        if (head[i] == '-' || head[i] == '>' || head[i] == '<')
        {
            return i;
        }
    }
    return 0;
}

unsigned int HandoverBlock::get_symbol_end_index (string head)
{
    for (unsigned int i = head.size() - 1; i >= 0; i--)
    {
        if (head[i] == '-' || head[i] == '>' || head[i] == '<')
        {
            return i;
        }
    }
    return head.size();
}

bool HandoverBlock::is_graphic_left_note (vector<string> orderedNodeName, string noteHead)
{
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    if(RegexUtil::reg_search(noteHead,"[^(note right)|(note left)]"))
    {
        ErrorStack::push_error("Before Line "+ ErrorStack::get_line_num_str()+ ": Note Key error");
    }
    return (nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(noteHead, "note left")) ||
           (! nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(noteHead, "note right"));
}

bool HandoverBlock::is_graphic_right_note (vector<string> orderedNodeName, string noteHead)
{
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    if(RegexUtil::reg_search(noteHead,"[^(note right)|(note left)]"))
    {
        ErrorStack::push_error("Before Line "+ ErrorStack::get_line_num_str()+ ": Note Key error");
    }
    return (nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(noteHead, "note right")) ||
           (! nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]) &&
            RegexUtil::reg_search(noteHead, "note left"));
}

void HandoverBlock::fake(vector<string> fakeNodeList)
{
    int fakeTimes = 0;
    for (unsigned int i=0; i< orderedNode.size(); i++)
    {
        string nodeName = orderedNode[i]->get_name();
        if (StringUtil::is_in_list(nodeName,fakeNodeList))
        {
            orderedNode[i]->set_attr_is_fake(true);
            ++fakeTimes;
        }
    }
    if (fakeTimes == FAKEBOUNDARY)
    {
        HandoverBlock::isFakeBoundary=true;
    }
}

vector<string> HandoverBlock::print()
{
    vector<string> result;
    vector<string> noteKeyWord;
    NodeGraphicSequence *nodeGraphicSequence = NodeGraphicSequence::getInstance();
    if (isFakeBoundary)
    {
        string headTemp;
        vector<string> orderedNodeName = get_ordered_node_name(true);
        nodeGraphicSequence->add_node(orderedNodeName[0]);
        nodeGraphicSequence->add_node(orderedNodeName[1]);
        if (nodeGraphicSequence->check_node_position(orderedNodeName[0], orderedNodeName[1]))
        {
            noteKeyWord = {"note left : ", "note right : "};
        }
        else
        {
            noteKeyWord = {"note right : ", "note left : "};
        }
        for (unsigned int i=0; i< orderedNode.size(); i++)
        {
            headTemp += orderedNode[i]->get_fake_name();
            if (i == 0)
            {
                headTemp += " " + symbol + " ";
            }
            if (orderedNode[i]->has_note_message())
            {
                result.push_back(noteKeyWord[i] + orderedNode[i]->get_note_messages_string());
            }
        }
        headTemp += " : " + message;
        result.insert(result.begin(), headTemp);
    }
    return result;
}

string HandoverBlock::get_subscribe_sessions()
{
    string result;
    if (isFakeBoundary)
    {
        Node* sourceNode = get_source_node();
        Node* targetNode = get_target_node();
        if (targetNode->is_fake())
        {
            result = sourceNode->get_sessions();
        }
    }
    return result;
}

string HandoverBlock::get_fake_messages()
{
    Node* sourceNode = get_source_node();
    string result = "";
    if(isFakeBoundary)
    {
        if (sourceNode->is_fake())
        {
            result += "Send " + message;
        }
        else
        {
            result += "Wait " + message;
        }
        if(sourceNode->has_note_message())
        {
            result += "(" + sourceNode->get_note_messages()->get_session() + "-"
                      + sourceNode->get_note_messages()->get_event()  + "-"
                      + sourceNode->get_note_messages()->get_key()
                      + ")";
        }
    }
    return result;
}

Node* HandoverBlock::get_target_node()
{
    for (unsigned int i=0; i<orderedNode.size(); i++)
    {
        if (orderedNode[i]->is_target())
        {
            return orderedNode[i];
        }
    }
    return nullptr;
}
Node* HandoverBlock::get_source_node()
{
    for (unsigned int i=0; i<orderedNode.size(); i++)
    {
        if (orderedNode[i]->is_source())
        {
            return orderedNode[i];
        }
    }
    return nullptr;
}

#endif // HANDOVER_BLOCK_H_INCLUDED
