#ifndef NOTE_MESSAGE_H_INCLUDED
#define NOTE_MESSAGE_H_INCLUDED

#include "regex_util.h"
#include "error_stack.h"

class NoteMessage {
private:
    string session;
    string event;
    string key;
    vector<string> other;

public:
    NoteMessage(string noteMessage, int lineNum) {
        vector<string> noteElements = StringUtil::split(noteMessage, ",");
        if (noteElements.size() < 3) {
            ErrorStack::push_error(lineNum, "Note Message Size less than 3");
            return;
        }
        session = StringUtil::erase_double_quotation(StringUtil::trim(noteElements[0]));
        event = StringUtil::trim(noteElements[1]);
        key = StringUtil::erase_double_quotation(StringUtil::trim(noteElements[2]));
        for (unsigned int i = 3; i < noteElements.size(); i++) {
            other.push_back(noteElements[i]);
        }
    }

    ~NoteMessage() {
        other.clear();
    }

    string get_session() {
        return session;
    }

    string get_event() {
        return event;
    }

    string get_key() {
        return key;
    }

    string dump () {
        string tmp = "\"" + session + "\", " + event + ", " + "\""+ key + "\"";
        for (unsigned int i = 0; i < other.size(); i++) {
            tmp += "," + other[i];
        }
        return tmp;
    }

};


#endif // NOTE_MESSAGE_H_INCLUDED
