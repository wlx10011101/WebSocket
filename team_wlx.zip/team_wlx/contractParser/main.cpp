#include <iostream>
#include "umlparser.h"
#include <unistd.h>
#include <getopt.h>
#include <fstream>
#include <stdlib.h>


using namespace std;

string inputFile;
string outputFile;
vector<string> fakeNodeList;
bool fakeSubscribePrint=false;
bool fakeFlowPrint=false;
bool output=true;

bool check_file_exist(char* inputFileName)
{
    if(inputFileName=="")
    {
        cout<<"NO INPUT FILE PARSER"<<endl;
        return false;
    }
    if((_access(inputFileName,F_OK)) == -1)
    {
        cout<<"INPUT FILE NOT EXIST"<<endl;
        return false;
    }
    return true;
}

int get_opt(int argc, char* argv[])
{

    char ch;
    int result = -1;
    while((ch = getopt(argc, argv, "i:f:o:sph")) != -1)
    {
        switch(ch)
        {
        case 'i':
            if (check_file_exist(optarg)){
                inputFile = optarg;
                result = 1;
            }
            break;
        case 'f':
            fakeNodeList = StringUtil::split(optarg, ",");
            break;
        case 'o':
            output = true;
            if (optarg)
            {
                outputFile = optarg;
            }
            break;
        case 's':
            fakeSubscribePrint = true;
            break;
        case 'p':
            fakeFlowPrint = true;
            break;
        default:
            cout<<"Usage: contractParser.exe [options] -i file"<<endl;
            cout<<"where options include:"<<endl;
            cout<<"\t-i\t Input file to parser"<<endl;
            cout<<"\t-f\t To fake Node,example: -fake \"BPF,STS\""<<endl;
            cout<<"\t-o\t To print fake result, or save to file,if file given"<<endl;
            cout<<"\t-s\t To print fake subscribe session"<<endl;
            cout<<"\t-p\t To print fake flow"<<endl;
            cout<<"\t-h\t To print help"<<endl;
            result = 0;
            break;
        }
    }
    return result;
}
void vector_string_print(vector<string> strs){
    for (unsigned int i=0; i< strs.size();i++){
        cout<< strs[i]<<endl;
    }
}

int main (int argc, char* argv[])
{
    int input = get_opt(argc, argv);
    if(input < 0){
        cout<<"NO INPUT FILE PARSER OR PARAMS ERROR"<<endl;
        return 1;
    }
    if (input == 0) return 0;
    UmlParser uml;
    if(!uml.parse(inputFile)||ErrorStack::is_error_exit()){
        vector_string_print(ErrorStack::pop_all_error());
        return 1;
    }

    if((!ErrorStack::is_error_exit())&&fakeNodeList.size())
    {
        cout<<"FAKE: ";
        for(unsigned int i=0; i<fakeNodeList.size();i++){
            cout<<fakeNodeList[i] + " ";
        }
        cout<<endl;
        uml.fake(fakeNodeList);
    }
    if((!ErrorStack::is_error_exit())&&output){
        if(outputFile != "")
        {
            cout<<"OUTPUT WRITE TO FILE"<<endl;
            uml.write_to_file(outputFile);
        }
        else
        {
            cout<<"OUTPUT WRITE TO CMD"<<endl;
            uml.write_to_cmd();
        }
    }
    if(fakeSubscribePrint){
        cout<<"OUTPUT SUBSCRIBE TO CMD"<<endl;
        uml.get_handovers().get_subscribe_sessions();
    }

    if(fakeFlowPrint){
        cout<<"OUTPUT FAKE FLOW TO CMD"<<endl;
        uml.get_handovers().print_fake_flow();
    }
    return 0;
}
