#ifndef NODE_GRAPHIC_SEQUENCE_H_INCLUDED
#define NODE_GRAPHIC_SEQUENCE_H_INCLUDED

#include <vector>
using namespace std;

class NodeGraphicSequence {
public:
    static NodeGraphicSequence *getInstance();
    ~NodeGraphicSequence() { nodeSequence.clear(); }
    static void add_node(string nodeName);
    static void add_node(vector<string> nodeNameList);
	static vector<string> get_node_sequence();
	static bool check_node_position(string leftNode, string rightNode);
	static void clear();

private:
    vector<string> nodeSequence;
    static NodeGraphicSequence* instance;
    NodeGraphicSequence();
    NodeGraphicSequence(const NodeGraphicSequence&);
	NodeGraphicSequence& operator=(const NodeGraphicSequence&);

	bool find_node(string nodeName);
};

NodeGraphicSequence* NodeGraphicSequence::instance = new NodeGraphicSequence();

NodeGraphicSequence::NodeGraphicSequence(){}

NodeGraphicSequence::NodeGraphicSequence(const NodeGraphicSequence&){}

NodeGraphicSequence& NodeGraphicSequence::operator=(const NodeGraphicSequence&){}

NodeGraphicSequence* NodeGraphicSequence::getInstance(){
	return instance;
}

void NodeGraphicSequence::add_node(string nodeName)
{
    if (getInstance()->find_node(nodeName))
        return;
    getInstance()->nodeSequence.push_back(nodeName);
}

void NodeGraphicSequence::add_node(vector<string> nodeNameList){
    for (unsigned int i=0; i<nodeNameList.size(); i++){
        if (!getInstance()->find_node(nodeNameList[i])){
            getInstance()->nodeSequence.push_back(nodeNameList[i]);
        }

    }
}

vector<string> NodeGraphicSequence::get_node_sequence()
{
    return getInstance()->nodeSequence;
}

bool NodeGraphicSequence::find_node(string nodeName)
{
    auto index=std::find(nodeSequence.begin(),nodeSequence.end(),nodeName);
    return index!=nodeSequence.end();
}

bool NodeGraphicSequence::check_node_position(string leftNode, string rightNode) {
    vector<string> nodeSequenceTemp = getInstance()->nodeSequence;
    auto leftTextGraphIndex = std::find(nodeSequenceTemp.begin(),nodeSequenceTemp.end(), leftNode);
    auto rightTextGraphIndex = std::find(nodeSequenceTemp.begin(),nodeSequenceTemp.end(), rightNode);
    return rightTextGraphIndex >= leftTextGraphIndex;
}

void NodeGraphicSequence::clear(){
    getInstance()->nodeSequence.clear();
}


#endif // NODE_GRAPHIC_SEQUENCE_H_INCLUDED
