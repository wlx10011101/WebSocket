# coding = utf-8
'''
@author: 10193332
'''
import md5
import os
import unittest
EXEPATH = os.path.abspath('../contractParser/bin/Debug/contractParser.exe')


class ContractParserTc(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

#     def test_fake_sts_and_write_to_cmd_window(self):
#         result = os.popen(EXEPATH + ' -i ./files/attach.wsd -f "STS"').read()
#         print result

    def test_no_fake_and_write_to_file(self):
        result = os.popen(EXEPATH + ' -i ./files/attach.wsd -o ./tmp/no_fake.wsd')
        testMd5 = md5.md5(open('./tmp/no_fake.wsd', 'r').read()).hexdigest()
        standard = md5.md5(open('./files/no_fake.wsd', 'r').read()).hexdigest()
        self.assertEqual(testMd5, standard, "no fake error")

    def test_fake_sts_and_write_to_file(self):
        result = os.popen(EXEPATH + ' -i ./files/attach.wsd -f "STS" -o ./tmp/fake_sts.wsd')
        testMd5 = md5.md5(open('./tmp/fake_sts.wsd', 'r').read()).hexdigest()
        standard = md5.md5(open('./files/fake_sts.wsd', 'r').read()).hexdigest()
        self.assertEqual(testMd5, standard, "fake sts error")

    def test_fake_bpf_and_write_to_file(self):
        result = os.popen(EXEPATH + ' -i ./files/attach.wsd -f "BPF" -o ./tmp/fake_bpf.wsd')
        testMd5 = md5.md5(open('./tmp/fake_bpf.wsd', 'r').read()).hexdigest()
        standard = md5.md5(open('./files/fake_bpf.wsd', 'r').read()).hexdigest()
        self.assertEqual(testMd5, standard, "fake bpf error")

    def test_fake_bpf_sts_and_write_to_file(self):
        result = os.popen(EXEPATH + ' -i ./files/attach.wsd -f "BPF,STS" -o ./tmp/fake_bpf_sts.wsd')
        testMd5 = md5.md5(open('./tmp/fake_bpf_sts.wsd', 'r').read()).hexdigest()
        standard = md5.md5(open('./files/fake_bpf_sts.wsd', 'r').read()).hexdigest()
        self.assertEqual(testMd5, standard, "fake bpf & sts error")

if __name__ == '__main__':
    unittest.main()
